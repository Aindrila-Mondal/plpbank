package com.cg.xyzbank.service;

import java.util.List;

import com.cg.xyzbank.bean.Customer;
import com.cg.xyzbank.bean.Transaction;

public interface ICustomerService {
	public int addCustomer(Customer customer);

	public Transaction depositMoney(int id, double amt);

	public Transaction withdrawMoney(int id, double amt);

	public Transaction fundTransfer(int id, int id2, double amt);

	public List<Customer> getAllDetails();
	
	public List<Transaction> getAllTransactionDetails();

	public Customer showBalance(int id);

}
