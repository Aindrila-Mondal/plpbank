package com.cg.xyzbank.dao;

import java.util.List;

import com.cg.xyzbank.bean.Customer;
import com.cg.xyzbank.bean.Transaction;

public interface ICustomerDao {

	public int addCustomer(Customer customer);

	public Transaction depositMoney(int id, double amt);

	public Transaction withdrawMoney(int id, double amt);

	public Transaction fundTransfer(int id, int id2, double amt);

	List<Customer> getAllDetails();
	
	List<Transaction> getAllTransactionDetails();
	
	Customer showBalance(int id);

}
